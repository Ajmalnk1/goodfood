<?php
/**
 * @cmsmasters_package 	Good Food
 * @cmsmasters_version 	1.0.4
 */


?>
<ul class="products columns-<?php echo esc_attr( wc_get_loop_prop( 'columns' ) ); ?> cmsmasters_products">